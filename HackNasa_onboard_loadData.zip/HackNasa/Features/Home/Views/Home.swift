//
//  Home.swift
//  HackNasa
//
//  Created by Angel Hernández Gámez on 04/10/25.
//

import SwiftUI

struct Home: View {
    var body: some View {
        NavigationSplitView {
            
        } detail: {
            
        }

    }
}

#Preview {
    Home()
}
