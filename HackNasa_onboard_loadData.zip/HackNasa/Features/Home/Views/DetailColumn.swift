//
//  DetailColumn.swift
//  HackNasa
//
//  Created by Angel Hernández Gámez on 04/10/25.
//

import SwiftUI

struct DetailColumn: View {
    var body: some View {
        
    }
}

#Preview {
    NavigationSplitView {
        
    } detail: {
        DetailColumn()
    }
}
