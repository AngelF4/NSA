//
//  HackNasaApp.swift
//  HackNasa
//
//  Created by Angel Hernández Gámez on 04/10/25.
//

import SwiftUI

@main
struct HackNasaApp: App {
    var body: some Scene {
        WindowGroup {
            OnboardingView()
        }
    }
}
