//
//  Radius.swift
//  HackNasa
//
//  Created by Angel Hernández Gámez on 04/10/25.
//

import Foundation

enum Radius {
    static let m: CGFloat = 12
}
